import { createClient } from '@supabase/supabase-js'

export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export type User = {
  id: string
  username: string
  display_name: string
  avatar_color: string
  pin_hash: string
  is_og: boolean       // true = one of the 6 OGs, can access group
  created_at: string
}

export type Message = {
  id: string
  user_id: string
  chat_id: string       // 'group' for group chat, or DM chat id
  content: string | null
  image_url: string | null
  reply_to: string | null
  deleted: boolean
  created_at: string
  user?: User
  replyMessage?: Message | null
}

export type Reaction = {
  id: string
  message_id: string
  user_id: string
  emoji: string
  user?: User
}

export type ReadReceipt = {
  message_id: string
  user_id: string
  read_at: string
  user?: User
}

export type DMChat = {
  id: string
  user_a: string
  user_b: string
  created_at: string
  otherUser?: User
  lastMessage?: Message
  unread?: number
}
