export function initSW() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  }
}

export async function requestNotificationPermission() {
  if (typeof window === 'undefined' || !('Notification' in window)) return false
  if (Notification.permission === 'granted') return true
  if (Notification.permission === 'denied') return false
  return (await Notification.requestPermission()) === 'granted'
}

export function sendNotification(title: string, body: string) {
  if (typeof window === 'undefined') return
  if (Notification.permission !== 'granted') return
  if (document.visibilityState === 'visible') return
  const n = new Notification(title, { body, icon: '/icon.svg', tag: 'vihats' })
  n.onclick = () => { window.focus(); n.close() }
  setTimeout(() => n.close(), 5000)
}
