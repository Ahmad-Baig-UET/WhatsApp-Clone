'use client'
import { useEffect, useRef, useState, useCallback } from 'react'
import Image from 'next/image'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/lib/store'
import { sendNotification } from '@/lib/notifications'
import type { Message, Reaction, ReadReceipt } from '@/lib/supabase'
import { format, isToday, isYesterday } from 'date-fns'
import { useDropzone } from 'react-dropzone'

type ExtMsg = Message & { reactions?: Reaction[]; read_receipts?: ReadReceipt[]; replyMessage?: ExtMsg | null }
const RXNS = ['❤️','👍','😂','😮','😢','🔥','👏','🎉','💀','😍']
const EMOJIS = ['😄','😂','❤️','👍','🔥','😮','😢','🎉','💀','👏','😍','🤣','😅','🙏','✨','😭','🤔','😎','🥳','😤','🫡','💯','🤯','😱','🥺','😴','🤪','😏','🙄','🫠','🫶','💪','🤝','👀','🎯','🤦','🙈','🐐','💅','🧢']

// ── Voice Player ──────────────────────────────────────────────────────────
function VoicePlayer({ url, isMine, ts }: { url: string; isMine: boolean; ts: string }) {
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [loaded, setLoaded] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    const a = new Audio(url)
    a.preload = 'metadata'
    a.onloadedmetadata = () => { setDuration(a.duration); setLoaded(true) }
    a.ontimeupdate = () => setProgress(a.currentTime / (a.duration || 1))
    a.onended = () => { setPlaying(false); setProgress(0) }
    audioRef.current = a
    return () => { a.pause(); a.src = '' }
  }, [url])

  const toggle = () => {
    const a = audioRef.current; if (!a) return
    if (playing) { a.pause(); setPlaying(false) }
    else { a.play().then(() => setPlaying(true)).catch(console.error) }
  }

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const a = audioRef.current; if (!a || !loaded) return
    const rect = e.currentTarget.getBoundingClientRect()
    a.currentTime = ((e.clientX - rect.left) / rect.width) * a.duration
  }

  const fmt = (s: number) => isNaN(s) ? '0:00' : `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`

  const bars = Array.from({ length: 30 }, (_, i) => {
    const h = 25 + ((url.charCodeAt(i % url.length) * (i + 1) * 13) % 55)
    return h
  })
  const played = Math.floor(progress * bars.length)

  return (
    <div className="flex items-center gap-3" style={{ minWidth: 210 }}>
      <button onClick={toggle} className="flex-shrink-0 flex items-center justify-center rounded-full transition-all hover:scale-105"
        style={{ width: 36, height: 36, background: 'linear-gradient(135deg,#00e5ff,#00b8cc)', boxShadow: '0 2px 12px rgba(0,229,255,0.3)' }}>
        {playing
          ? <svg width="12" height="12" viewBox="0 0 24 24" fill="#080b14"><rect x="6" y="4" width="4" height="16" rx="1" /><rect x="14" y="4" width="4" height="16" rx="1" /></svg>
          : <svg width="12" height="12" viewBox="0 0 24 24" fill="#080b14"><polygon points="6,3 20,12 6,21" /></svg>
        }
      </button>
      <div className="flex-1 flex flex-col gap-1.5">
        <div className="flex items-center gap-[2px] cursor-pointer" style={{ height: 28 }} onClick={seek}>
          {bars.map((h, i) => (
            <div key={i} className="flex-1 rounded-full transition-colors duration-75"
              style={{ height: `${h}%`, background: i < played ? '#00e5ff' : isMine ? 'rgba(0,229,255,0.22)' : 'rgba(255,255,255,0.1)' }} />
          ))}
        </div>
        <div className="flex justify-between items-center">
          <span style={{ fontSize: 10, color: isMine ? 'rgba(0,229,255,0.55)' : 'rgba(255,255,255,0.28)' }}>
            {playing ? fmt(audioRef.current?.currentTime || 0) : fmt(duration)}
          </span>
          <span style={{ fontSize: 10, color: isMine ? 'rgba(0,229,255,0.4)' : 'rgba(255,255,255,0.2)' }}>{ts}</span>
        </div>
      </div>
    </div>
  )
}

// ── ChatWindow ────────────────────────────────────────────────────────────
export default function ChatWindow({ chatId, title, subtitle, avatarColor, isGroup = false }: {
  chatId: string; title: string; subtitle?: string; avatarColor?: string; isGroup?: boolean
}) {
  const user = useAuthStore(s => s.user)!
  const [msgs, setMsgs] = useState<ExtMsg[]>([])
  const [loading, setLoading] = useState(true)
  const [text, setText] = useState('')
  const [uploading, setUploading] = useState(false)
  const [replyTo, setReplyTo] = useState<ExtMsg | null>(null)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [rxFor, setRxFor] = useState<string | null>(null)
  const [unread, setUnread] = useState(0)
  const [atBottom, setAtBottom] = useState(true)
  const [rec, setRec] = useState(false)
  const [recSec, setRecSec] = useState(0)
  const [typing, setTyping] = useState<string[]>([])
  const [imgPrev, setImgPrev] = useState<string | null>(null)

  const scrollRef = useRef<HTMLDivElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLTextAreaElement>(null)
  const chRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const mrRef = useRef<MediaRecorder | null>(null)
  const chunks = useRef<Blob[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const atBottomRef = useRef(true)

  // ── Mark read ────────────────────────────────────────────────────────────
  const markRead = useCallback(async (ids: string[]) => {
    if (!ids.length) return
    await supabase.from('read_receipts').upsert(
      ids.map(id => ({ message_id: id, user_id: user.id })),
      { onConflict: 'message_id,user_id' }
    )
  }, [user.id])

  // ── Load messages — reset state first to prevent flash ───────────────────
  const loadMsgs = useCallback(async () => {
    setLoading(true)
    setMsgs([])        // clear immediately so old chat doesn't flash
    setUnread(0)
    setReplyTo(null)
    setText('')

    const [m, r, rr] = await Promise.all([
      supabase.from('messages').select('*, user:users(id,display_name,avatar_color)').eq('chat_id', chatId).order('created_at', { ascending: true }).limit(200),
      supabase.from('reactions').select('id,message_id,user_id,emoji,user:users(display_name)'),
      supabase.from('read_receipts').select('id,message_id,user_id,read_at,user:users(display_name,avatar_color)'),
    ])

    const messages = m.data || []
    const reactions = r.data || []
    const receipts = rr.data || []

    const map = new Map<string, ExtMsg>()
    messages.forEach((msg: ExtMsg) => {
      msg.reactions = reactions.filter((rx: Reaction) => rx.message_id === msg.id)
      msg.read_receipts = receipts.filter((rc: ReadReceipt) => rc.message_id === msg.id)
      map.set(msg.id, msg)
    })
    messages.forEach((msg: ExtMsg) => {
      if (msg.reply_to) msg.replyMessage = map.get(msg.reply_to) || null
    })

    setMsgs(messages as ExtMsg[])
    setLoading(false)

    // Scroll to bottom instantly after load
    requestAnimationFrame(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    })

    // Mark unread as read
    const unreadIds = messages
      .filter((msg: ExtMsg) => msg.user_id !== user.id && !receipts.find((rc: ReadReceipt) => rc.message_id === msg.id && rc.user_id === user.id))
      .map((msg: ExtMsg) => msg.id)
    markRead(unreadIds)
  }, [chatId, user.id, markRead])

  // Reload when chatId changes
  useEffect(() => { loadMsgs() }, [loadMsgs])

  // ── Realtime subscription — remount on chatId change ─────────────────────
  useEffect(() => {
    // Cleanup old channel first
    if (chRef.current) { supabase.removeChannel(chRef.current); chRef.current = null }

    const ch = supabase.channel(`chat:${chatId}:${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` }, async ({ new: row }) => {
        const { data } = await supabase.from('messages').select('*, user:users(id,display_name,avatar_color)').eq('id', row.id).single()
        if (!data) return
        const msg = data as ExtMsg
        msg.reactions = []; msg.read_receipts = []
        if (msg.reply_to) {
          const { data: rep } = await supabase.from('messages').select('*, user:users(*)').eq('id', msg.reply_to).single()
          msg.replyMessage = rep as ExtMsg
        }
        setMsgs(prev => {
          if (prev.some(m => m.id === msg.id)) return prev
          return [...prev, msg]
        })
        if (msg.user_id !== user.id) {
          const preview = msg.content === '🎤 Voice message' ? '🎤 Voice message' : msg.image_url ? '🖼️ Image' : msg.content || ''
          sendNotification(`${msg.user?.display_name}${isGroup ? ' (Group)' : ''}`, preview)
          if (atBottomRef.current) {
            markRead([msg.id])
            requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }))
          } else {
            setUnread(c => c + 1)
          }
        } else {
          markRead([msg.id])
          requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }))
        }
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, ({ new: row }) => {
        setMsgs(prev => prev.map(m => m.id === row.id ? { ...m, deleted: row.deleted, content: row.content, image_url: row.image_url } : m))
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reactions' }, async ({ new: row }) => {
        const { data } = await supabase.from('reactions').select('id,message_id,user_id,emoji,user:users(display_name)').eq('id', row.id).single()
        if (!data) return
        setMsgs(prev => prev.map(m => m.id === row.message_id
          ? { ...m, reactions: [...(m.reactions || []).filter(r => r.id !== row.id), data as Reaction] }
          : m))
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'reactions' }, ({ old: row }) => {
        setMsgs(prev => prev.map(m => ({ ...m, reactions: (m.reactions || []).filter(r => r.id !== row.id) })))
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'read_receipts' }, async ({ new: row }) => {
        const { data } = await supabase.from('read_receipts').select('id,message_id,user_id,read_at,user:users(display_name,avatar_color)').eq('id', row.id).single()
        if (!data) return
        setMsgs(prev => prev.map(m => m.id === row.message_id
          ? { ...m, read_receipts: [...(m.read_receipts || []).filter(r => r.id !== row.id), data as ReadReceipt] }
          : m))
      })
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        if (payload.uid === user.id) return
        setTyping(prev => prev.includes(payload.name) ? prev : [...prev, payload.name])
        setTimeout(() => setTyping(prev => prev.filter(n => n !== payload.name)), 2500)
      })
      .subscribe()

    chRef.current = ch
    return () => { if (chRef.current) { supabase.removeChannel(chRef.current); chRef.current = null } }
  }, [chatId, user.id, isGroup, markRead])

  // ── Scroll handler ───────────────────────────────────────────────────────
  const onScroll = useCallback(() => {
    const el = scrollRef.current; if (!el) return
    const bottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    setAtBottom(bottom); atBottomRef.current = bottom
    if (bottom) setUnread(0)
  }, [])

  // ── Send text ────────────────────────────────────────────────────────────
  const send = async () => {
    const content = text.trim(); if (!content) return
    setText(''); if (textRef.current) textRef.current.style.height = 'auto'
    const { data } = await supabase.from('messages').insert({
      user_id: user.id, chat_id: chatId, content, reply_to: replyTo?.id || null
    }).select().single()
    setReplyTo(null)
    if (data) markRead([data.id])
  }

  const onKey = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }

  const onTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value)
    chRef.current?.send({ type: 'broadcast', event: 'typing', payload: { uid: user.id, name: user.display_name } })
    e.target.style.height = 'auto'
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
  }

  // ── Image upload ─────────────────────────────────────────────────────────
  const onDrop = useCallback(async (files: File[]) => {
    const f = files[0]; if (!f?.type.startsWith('image/')) return
    setUploading(true)
    const path = `${user.id}/${Date.now()}.${f.name.split('.').pop()}`
    const { error } = await supabase.storage.from('chat-images').upload(path, f, { contentType: f.type })
    if (!error) {
      const { data } = supabase.storage.from('chat-images').getPublicUrl(path)
      await supabase.from('messages').insert({ user_id: user.id, chat_id: chatId, content: null, image_url: data.publicUrl, reply_to: replyTo?.id || null })
      setReplyTo(null)
    }
    setUploading(false)
  }, [user.id, chatId, replyTo])

  const { getRootProps, getInputProps, isDragActive, open: openFile } = useDropzone({
    onDrop, accept: { 'image/*': [] }, noClick: true, noKeyboard: true
  })

  // ── Delete ───────────────────────────────────────────────────────────────
  const del = (id: string) => supabase.from('messages').update({ deleted: true, content: null, image_url: null }).eq('id', id)

  // ── Reactions ────────────────────────────────────────────────────────────
  const toggleRx = async (msgId: string, emoji: string) => {
    const msg = msgs.find(m => m.id === msgId)
    const ex = msg?.reactions?.find(r => r.user_id === user.id && r.emoji === emoji)
    if (ex) await supabase.from('reactions').delete().eq('id', ex.id)
    else await supabase.from('reactions').insert({ message_id: msgId, user_id: user.id, emoji })
    setRxFor(null)
  }

  // ── Voice ────────────────────────────────────────────────────────────────
  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm'
      const mr = new MediaRecorder(stream, { mimeType: mime })
      chunks.current = []
      mr.ondataavailable = e => { if (e.data.size > 0) chunks.current.push(e.data) }
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop())
        const blob = new Blob(chunks.current, { type: 'audio/webm' })
        if (blob.size < 200) return
        setUploading(true)
        const path = `${user.id}/voice-${Date.now()}.webm`
        const { error } = await supabase.storage.from('voice-messages').upload(path, blob, { contentType: 'audio/webm' })
        if (!error) {
          const { data } = supabase.storage.from('voice-messages').getPublicUrl(path)
          await supabase.from('messages').insert({ user_id: user.id, chat_id: chatId, content: '🎤 Voice message', image_url: data.publicUrl })
        } else {
          alert('Voice upload failed. Make sure the "voice-messages" storage bucket exists and is public in Supabase.')
        }
        setUploading(false)
      }
      mr.start(100); mrRef.current = mr; setRec(true); setRecSec(0)
      timerRef.current = setInterval(() => setRecSec(t => t + 1), 1000)
    } catch { alert('Mic access denied. Allow microphone in browser settings.') }
  }

  const stopRec = () => {
    if (mrRef.current?.state !== 'inactive') mrRef.current?.stop()
    setRec(false); if (timerRef.current) clearInterval(timerRef.current)
  }

  // ── Helpers ──────────────────────────────────────────────────────────────
  const ft = (ts: string) => { const d = new Date(ts); if (isToday(d)) return format(d,'HH:mm'); if (isYesterday(d)) return `Yesterday ${format(d,'HH:mm')}`; return format(d,'MMM d, HH:mm') }
  const fd = (ts: string) => { const d = new Date(ts); if (isToday(d)) return 'Today'; if (isYesterday(d)) return 'Yesterday'; return format(d,'MMMM d, yyyy') }

  const grouped: { date: string; msgs: ExtMsg[] }[] = []
  msgs.forEach(m => {
    const dk = format(new Date(m.created_at), 'yyyy-MM-dd')
    const last = grouped[grouped.length - 1]
    if (last?.date === dk) last.msgs.push(m)
    else grouped.push({ date: dk, msgs: [m] })
  })

  const grpRx = (reactions: Reaction[]) => {
    const map: Record<string, { count: number; users: string[]; mine: boolean }> = {}
    reactions.forEach(r => {
      if (!map[r.emoji]) map[r.emoji] = { count: 0, users: [], mine: false }
      map[r.emoji].count++
      const dn = (r.user as { display_name?: string })?.display_name
      if (dn) map[r.emoji].users.push(dn)
      if (r.user_id === user.id) map[r.emoji].mine = true
    })
    return map
  }

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col overflow-hidden" style={{ height: '100%' }} {...getRootProps()}>
      <input {...getInputProps()} />

      {/* Drop overlay */}
      {isDragActive && (
        <div className="absolute inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(8,11,20,0.92)', border: '2px dashed rgba(0,229,255,0.4)' }}>
          <div className="text-center"><div className="text-5xl mb-3">🖼️</div><p className="font-display text-lg" style={{ color: '#00e5ff' }}>Drop to send</p></div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-3 flex-shrink-0" style={{ background: '#090d18', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        {isGroup
          ? <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(145deg,#003544,#004a5e)', border: '1px solid rgba(0,229,255,0.22)' }}>
              <svg width="15" height="15" viewBox="0 0 40 40" fill="none"><path d="M20 3C10.61 3 3 10.61 3 20c0 3.12.83 6.04 2.27 8.57L3 37l8.74-2.22A16.9 16.9 0 0020 37c9.39 0 17-7.61 17-17S29.39 3 20 3z" fill="#00e5ff" /></svg>
            </div>
          : <div className="av w-9 h-9 rounded-xl text-sm flex-shrink-0"
              style={{ background: (avatarColor || '#888') + '22', color: avatarColor || '#888' }}>
              {title[0]?.toUpperCase()}
            </div>
        }
        <div>
          <p className="font-display font-semibold text-sm" style={{ color: '#f0f6ff' }}>{title}</p>
          {subtitle && <p className="text-xs" style={{ color: 'rgba(255,255,255,0.28)' }}>{subtitle}</p>}
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-y-auto chat-bg px-4 py-4" style={{ overscrollBehavior: 'contain' }}>
        {loading && (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 rounded-full border-2 border-t-transparent spin" style={{ borderColor: 'rgba(0,229,255,0.3)', borderTopColor: 'transparent' }} />
          </div>
        )}
        {!loading && grouped.map(({ date, msgs: dayMsgs }) => (
          <div key={date}>
            <div className="flex justify-center my-4">
              <span className="text-xs px-3 py-1 rounded-full font-display" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.28)' }}>
                {fd(dayMsgs[0].created_at)}
              </span>
            </div>
            {dayMsgs.map((msg, i) => {
              const mine = msg.user_id === user.id
              const showAv = !mine && (i === 0 || dayMsgs[i - 1]?.user_id !== msg.user_id)
              const showName = showAv && isGroup
              const rg = grpRx(msg.reactions || [])
              const readBy = (msg.read_receipts || []).filter(r => r.user_id !== msg.user_id)
              const isVoice = !msg.deleted && msg.image_url && msg.content === '🎤 Voice message'
              const isImg = !msg.deleted && msg.image_url && msg.content !== '🎤 Voice message'

              return (
                <div key={msg.id} className={`flex gap-2 mb-1.5 group ${mine ? 'justify-end' : 'justify-start'}`}>
                  {/* Avatar */}
                  {!mine && (
                    <div className="w-7 flex-shrink-0 flex items-end pb-0.5">
                      {showAv
                        ? <div className="av w-7 h-7 rounded-lg text-[11px]" style={{ background: (msg.user?.avatar_color || '#888') + '22', color: msg.user?.avatar_color || '#888' }}>
                            {(msg.user?.display_name || '?')[0].toUpperCase()}
                          </div>
                        : <div className="w-7" />
                      }
                    </div>
                  )}

                  <div className={`max-w-[68%] flex flex-col ${mine ? 'items-end' : 'items-start'}`}>
                    {showName && (
                      <p className="text-xs font-semibold mb-1 ml-0.5" style={{ color: msg.user?.avatar_color }}>{msg.user?.display_name}</p>
                    )}

                    <div className="relative">
                      {/* Bubble */}
                      <div className={`relative px-3.5 py-2.5 ${mine ? 'bubble-mine' : 'bubble-theirs'}`}
                        style={{ opacity: msg.deleted ? 0.45 : 1 }}>
                        {/* Reply preview */}
                        {msg.replyMessage && !msg.deleted && (
                          <div className="mb-2.5 pl-2.5 py-1.5 rounded-lg"
                            style={{ borderLeft: `2px solid ${mine ? 'rgba(0,229,255,0.45)' : 'rgba(255,255,255,0.2)'}`, background: 'rgba(0,0,0,0.15)' }}>
                            <p className="text-xs font-semibold mb-0.5" style={{ color: msg.replyMessage.user?.avatar_color }}>
                              {msg.replyMessage.user?.display_name}
                            </p>
                            <p className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.35)' }}>
                              {msg.replyMessage.deleted ? '🚫 Deleted' : msg.replyMessage.content || '🖼️ Image'}
                            </p>
                          </div>
                        )}

                        {/* Content */}
                        {msg.deleted
                          ? <p className="text-sm italic" style={{ color: 'rgba(255,255,255,0.28)' }}>🚫 Deleted</p>
                          : isVoice
                          ? <VoicePlayer url={msg.image_url!} isMine={mine} ts={ft(msg.created_at)} />
                          : isImg
                          ? <div className="-mx-1 -my-0.5">
                              <Image src={msg.image_url!} alt="img" width={280} height={280}
                                className="rounded-2xl object-cover cursor-pointer block"
                                onClick={() => setImgPrev(msg.image_url!)} />
                              <p className="text-right text-[10px] mt-1 mr-1" style={{ color: 'rgba(255,255,255,0.35)' }}>{ft(msg.created_at)}</p>
                            </div>
                          : <div className="flex flex-wrap items-end gap-x-2 gap-y-0.5">
                              <p className="text-sm leading-relaxed whitespace-pre-wrap break-words" style={{ color: 'rgba(255,255,255,0.88)' }}>{msg.content}</p>
                              <div className="flex items-center gap-1.5 self-end flex-shrink-0 ml-auto">
                                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.28)' }}>{ft(msg.created_at)}</span>
                                {mine && (readBy.length > 0
                                  ? <svg width="16" height="10" viewBox="0 0 16 10" fill="none"><path d="M1 5l3 3 5-7" stroke="#00e5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /><path d="M5 5l3 3 5-7" stroke="#00e5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                                  : <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 5l3 3 5-7" stroke="rgba(255,255,255,0.28)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                                )}
                              </div>
                            </div>
                        }
                      </div>

                      {/* Hover actions */}
                      {!msg.deleted && (
                        <div className={`absolute top-0 ${mine ? 'right-full pr-1.5' : 'left-full pl-1.5'} flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10`}
                          style={{ transform: 'translateY(2px)' }}>
                          <button onClick={() => setRxFor(rxFor === msg.id ? null : msg.id)}
                            className="w-7 h-7 rounded-lg text-sm flex items-center justify-center transition-all hover:scale-110"
                            style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.08)' }}>😊</button>
                          <button onClick={() => { setReplyTo(msg); textRef.current?.focus() }}
                            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                            style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.08)' }}>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth="2.5"><path d="M3 10h11a4 4 0 010 8h-1M3 10l4-4M3 10l4 4" /></svg>
                          </button>
                          {mine && (
                            <button onClick={() => del(msg.id)}
                              className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:scale-110"
                              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.15)' }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(239,68,68,0.7)" strokeWidth="2.5"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
                            </button>
                          )}
                        </div>
                      )}

                      {/* Reaction picker */}
                      {rxFor === msg.id && (
                        <div className={`absolute z-20 bottom-full mb-1.5 ${mine ? 'right-0' : 'left-0'} rounded-2xl p-2 shadow-2xl api`}
                          style={{ background: '#0e1825', border: '1px solid rgba(255,255,255,0.08)' }}>
                          <div className="flex gap-0.5">
                            {RXNS.map(e => (
                              <button key={e} onClick={() => toggleRx(msg.id, e)}
                                className="w-9 h-9 rounded-xl flex items-center justify-center text-lg transition-transform hover:scale-125">{e}</button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Reactions */}
                    {Object.keys(rg).length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {Object.entries(rg).map(([emoji, d]) => (
                          <button key={emoji} onClick={() => toggleRx(msg.id, emoji)} title={d.users.join(', ')}
                            className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-all hover:scale-105"
                            style={d.mine
                              ? { background: 'rgba(0,229,255,0.1)', borderColor: 'rgba(0,229,255,0.3)', color: '#00e5ff' }
                              : { background: 'rgba(255,255,255,0.04)', borderColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.45)' }}>
                            {emoji} <span>{d.count}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Read by */}
                    {mine && readBy.length > 0 && (
                      <div className="flex gap-0.5 mt-1">
                        {readBy.slice(0, 5).map(r => {
                          const ac = (r.user as { avatar_color?: string })?.avatar_color
                          const dn = (r.user as { display_name?: string })?.display_name
                          return (
                            <div key={r.user_id} title={dn} className="av w-4 h-4 rounded text-[9px]"
                              style={{ background: (ac || '#888') + '33', color: ac }}>
                              {(dn || '?')[0].toUpperCase()}
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        ))}

        {/* Typing */}
        {typing.length > 0 && (
          <div className="flex items-center gap-2 mt-2 afi">
            <div className="w-7" />
            <div className="bubble-theirs px-4 py-2.5 flex items-center gap-1.5">
              <span className="text-xs mr-1" style={{ color: 'rgba(255,255,255,0.3)' }}>{typing.join(', ')}</span>
              {[0,1,2].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.25)', animation: `tdot 1.3s ease-in-out ${i*.18}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Unread badge */}
      {unread > 0 && (
        <button onClick={() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); setUnread(0) }}
          className="absolute bottom-24 right-5 text-xs font-bold font-display px-3 py-1.5 rounded-full z-20 api flex items-center gap-1.5"
          style={{ background: '#00e5ff', color: '#080b14', boxShadow: '0 4px 20px rgba(0,229,255,0.45)' }}>
          ↓ {unread} new
        </button>
      )}

      {/* Reply bar */}
      {replyTo && (
        <div className="flex items-center gap-3 px-4 py-2.5 flex-shrink-0 afi" style={{ background: '#0c1422', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <div className="flex-1 pl-3 py-1" style={{ borderLeft: '2px solid rgba(0,229,255,0.5)' }}>
            <p className="text-xs font-semibold mb-0.5" style={{ color: replyTo.user?.avatar_color }}>{replyTo.user?.display_name}</p>
            <p className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.28)' }}>{replyTo.content || '🖼️ Image'}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="flex-shrink-0 transition-opacity hover:opacity-60" style={{ color: 'rgba(255,255,255,0.3)' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        </div>
      )}

      {/* Input */}
      <div className="flex items-end gap-2 px-3 py-3 flex-shrink-0" style={{ background: '#090d18', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        {/* Emoji */}
        <div className="relative flex-shrink-0">
          <button onClick={() => setEmojiOpen(!emojiOpen)}
            className="w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-all hover:scale-110"
            style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>😊</button>
          {emojiOpen && (
            <div className="absolute bottom-12 left-0 rounded-2xl p-3 shadow-2xl z-30 api w-[288px]"
              style={{ background: '#0c1422', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="grid grid-cols-8 gap-0.5 max-h-48 overflow-y-auto">
                {EMOJIS.map(e => (
                  <button key={e} onClick={() => { setText(t => t + e); setEmojiOpen(false); textRef.current?.focus() }}
                    className="w-8 h-8 rounded-lg text-xl flex items-center justify-center hover:scale-110 hover:bg-white/10 transition-all">{e}</button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Image */}
        <button onClick={openFile} disabled={uploading}
          className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center transition-all hover:scale-110"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.35)' }}>
          {uploading
            ? <div className="w-4 h-4 rounded-full border-2 border-t-transparent spin" style={{ borderColor: 'rgba(0,229,255,0.4)', borderTopColor: 'transparent' }} />
            : <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
          }
        </button>

        {/* Textarea */}
        <div className="flex-1 rounded-2xl flex items-end px-4 py-2.5" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
          <textarea ref={textRef} value={text} onChange={onTextChange} onKeyDown={onKey}
            placeholder="Message..." rows={1}
            className="flex-1 bg-transparent text-sm resize-none outline-none leading-6 placeholder:opacity-100"
            style={{ color: 'rgba(255,255,255,0.88)', caretColor: '#00e5ff', maxHeight: 120 }} />
        </div>

        {/* Send / Mic */}
        {text.trim()
          ? <button onClick={send}
              className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center transition-all hover:scale-110"
              style={{ background: 'linear-gradient(135deg,#00e5ff,#00b8cc)', color: '#080b14', boxShadow: '0 2px 16px rgba(0,229,255,0.35)' }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z" /></svg>
            </button>
          : <button onMouseDown={startRec} onMouseUp={stopRec} onTouchStart={startRec} onTouchEnd={stopRec}
              className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center transition-all"
              style={rec
                ? { background: '#ef4444', boxShadow: '0 0 0 0 rgba(239,68,68,0.5)', animation: 'recPulse 1s infinite' }
                : { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
              {rec
                ? <span className="font-display font-bold text-white text-[11px]">{recSec}s</span>
                : <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth="2"><rect x="9" y="2" width="6" height="11" rx="3" /><path d="M5 10a7 7 0 0014 0M12 19v3M8 22h8" /></svg>
              }
            </button>
        }
      </div>

      {/* Lightbox */}
      {imgPrev && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm" style={{ background: 'rgba(0,0,0,0.92)' }} onClick={() => setImgPrev(null)}>
          <Image src={imgPrev} alt="preview" width={900} height={900} className="max-w-full max-h-full object-contain rounded-2xl" />
        </div>
      )}

      {/* Close overlays */}
      {(emojiOpen || rxFor) && (
        <div className="fixed inset-0 z-10" onClick={() => { setEmojiOpen(false); setRxFor(null) }} />
      )}
    </div>
  )
}
