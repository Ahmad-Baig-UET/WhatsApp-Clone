'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { hashPin } from '@/lib/hash'
import { useAuthStore } from '@/lib/store'
import { requestNotificationPermission, initSW } from '@/lib/notifications'
import type { User } from '@/lib/supabase'

export default function LoginPage() {
  const router = useRouter()
  const setUser = useAuthStore(s => s.setUser)
  const [step, setStep] = useState<'user' | 'pin'>('user')
  const [username, setUsername] = useState('')
  const [found, setFound] = useState<User | null>(null)
  const [pin, setPin] = useState(['', '', '', ''])
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const [shake, setShake] = useState(false)
  const pinRefs = useRef<(HTMLInputElement | null)[]>([])

  const findUser = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim()) return
    setLoading(true); setErr('')
    const { data } = await supabase.from('users').select('*').ilike('username', username.trim()).single()
    setLoading(false)
    if (!data) { setErr('No account found. Check username or sign up.'); return }
    setFound(data as User); setStep('pin')
    setTimeout(() => pinRefs.current[0]?.focus(), 80)
  }

  const onPinChange = (i: number, val: string) => {
    if (!/^\d*$/.test(val)) return
    const p = [...pin]; p[i] = val.slice(-1); setPin(p)
    if (val && i < 3) pinRefs.current[i + 1]?.focus()
    if (p.every(d => d)) submitPin(p.join(''))
  }

  const onPinKey = (i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pin[i] && i > 0) pinRefs.current[i - 1]?.focus()
  }

  const submitPin = async (val: string) => {
    if (!found) return
    setLoading(true)
    const hashed = await hashPin(val)
    if (hashed === found.pin_hash) {
      setUser(found); initSW(); await requestNotificationPermission()
      router.push('/chat')
    } else {
      setLoading(false); setShake(true); setErr('Wrong PIN. Try again.')
      setPin(['', '', '', ''])
      setTimeout(() => { setShake(false); pinRefs.current[0]?.focus() }, 500)
    }
  }

  return (
    <div className="h-screen flex items-center justify-center p-4 relative overflow-hidden" style={{ background: '#080b14' }}>
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center" style={{ transform: 'translateY(-60px)' }}>
        <div style={{ width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(0,229,255,0.05) 0%, transparent 70%)' }} />
      </div>

      <div className="w-full max-w-[360px] relative z-10">
        {/* Logo */}
        <div className="text-center mb-10 afu">
          <div className="inline-flex items-center justify-center w-[72px] h-[72px] rounded-[22px] mb-5"
            style={{ background: 'linear-gradient(145deg,#0a1e2c,#003d4d)', border: '1px solid rgba(0,229,255,0.18)', boxShadow: '0 8px 32px rgba(0,229,255,0.1)' }}>
            <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
              <path d="M20 3C10.61 3 3 10.61 3 20c0 3.12.83 6.04 2.27 8.57L3 37l8.74-2.22A16.9 16.9 0 0020 37c9.39 0 17-7.61 17-17S29.39 3 20 3z" fill="#00e5ff" />
              <path d="M29 22.5c-.38-.19-2.22-1.1-2.57-1.22-.34-.12-.6-.18-.85.18-.25.37-.98 1.22-1.2 1.47-.21.25-.43.28-.81.09-.38-.19-1.59-.59-3.03-1.87-1.12-1-1.87-2.23-2.09-2.6-.22-.38-.02-.58.16-.77.17-.17.38-.44.57-.66.18-.22.25-.38.38-.63.12-.25.06-.47-.03-.66-.09-.19-.85-2.06-1.17-2.81-.3-.74-.62-.64-.85-.64-.22-.01-.47-.01-.72-.01-.25 0-.66.09-1 .47-.35.38-1.32 1.28-1.32 3.12s1.35 3.62 1.53 3.87c.18.25 2.64 4.03 6.41 5.65.89.38 1.59.62 2.13.78.9.28 1.71.24 2.36.15.72-.11 2.22-.91 2.54-1.79.31-.88.31-1.63.22-1.79-.1-.16-.35-.25-.72-.44z" fill="#080b14" />
            </svg>
          </div>
          <h1 className="font-display text-[28px] font-bold tracking-tight" style={{ color: '#f0f6ff' }}>VI-hatsApp</h1>
          <p className="text-sm mt-1.5" style={{ color: 'rgba(255,255,255,0.28)' }}>Your private chat space</p>
        </div>

        {step === 'user' ? (
          <form onSubmit={findUser} className="afu" style={{ animationDelay: '.08s' }}>
            <div className="mb-4">
              <label className="block text-xs font-display font-semibold uppercase tracking-[.12em] mb-2.5" style={{ color: 'rgba(255,255,255,0.22)' }}>Username</label>
              <input value={username} onChange={e => { setUsername(e.target.value); setErr('') }}
                placeholder="your_username" autoFocus
                className="w-full rounded-2xl px-4 py-[15px] text-base outline-none transition-all placeholder:opacity-30"
                style={{ background: '#0e1520', border: '1.5px solid #1a2640', color: '#f0f6ff' }}
                onFocus={e => e.target.style.borderColor = '#00e5ff'}
                onBlur={e => e.target.style.borderColor = '#1a2640'} />
            </div>
            {err && <p className="text-red-400 text-sm mb-4 afi">{err}</p>}
            <button type="submit" disabled={!username.trim() || loading}
              className="w-full py-[15px] rounded-2xl font-display font-bold text-base transition-all disabled:opacity-40 flex items-center justify-center gap-2"
              style={{ background: 'linear-gradient(135deg,#00e5ff,#00b8cc)', color: '#080b14', boxShadow: '0 4px 24px rgba(0,229,255,0.25)' }}>
              {loading
                ? <span className="w-5 h-5 rounded-full border-2 border-[#080b14]/40 border-t-[#080b14] spin inline-block" />
                : 'Log In →'}
            </button>
            <p className="text-center mt-6 text-sm" style={{ color: 'rgba(255,255,255,0.25)' }}>
              Don't have an account?{' '}
              <Link href="/auth/signup" className="underline underline-offset-2" style={{ color: '#00e5ff' }}>Sign up</Link>
            </p>
          </form>
        ) : (
          <div className="afu">
            <button onClick={() => { setStep('user'); setErr(''); setPin(['', '', '', '']) }}
              className="flex items-center gap-1.5 text-sm mb-8 transition-opacity hover:opacity-60"
              style={{ color: 'rgba(255,255,255,0.35)' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 18l-6-6 6-6" /></svg>
              Back
            </button>
            <div className="text-center mb-8">
              <div className="av w-[68px] h-[68px] rounded-[18px] text-2xl mx-auto mb-3"
                style={{ background: found!.avatar_color + '20', color: found!.avatar_color, border: `2px solid ${found!.avatar_color}35` }}>
                {found!.display_name[0].toUpperCase()}
              </div>
              <p className="font-semibold text-lg" style={{ color: '#f0f6ff' }}>{found!.display_name}</p>
              <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.28)' }}>Enter your 4-digit PIN</p>
            </div>
            <div className={`flex justify-center gap-3 mb-4 ${shake ? 'shake' : ''}`}>
              {pin.map((d, i) => (
                <input key={i} ref={el => { pinRefs.current[i] = el }}
                  type="password" inputMode="numeric" maxLength={1} value={d}
                  onChange={e => onPinChange(i, e.target.value)}
                  onKeyDown={e => onPinKey(i, e)}
                  className="pin-box" disabled={loading} />
              ))}
            </div>
            {err && <p className="text-center text-red-400 text-sm mt-2 afi">{err}</p>}
            {loading && (
              <div className="flex justify-center gap-2 mt-5">
                {[0, 1, 2].map(i => <div key={i} className="w-2 h-2 rounded-full" style={{ background: '#00e5ff', animation: `tdot 1.3s ease-in-out ${i * .18}s infinite` }} />)}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
