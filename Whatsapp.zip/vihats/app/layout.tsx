import type { Metadata } from 'next'
import { Syne, Outfit } from 'next/font/google'
import './globals.css'

const display = Syne({ subsets: ['latin'], variable: '--font-display', weight: ['400','600','700','800'] })
const body = Outfit({ subsets: ['latin'], variable: '--font-body', weight: ['300','400','500','600'] })

export const metadata: Metadata = {
  title: 'VI-hatsApp',
  description: 'Chat with your people',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body className="bg-ink-950 text-slate-text font-body antialiased">{children}</body>
    </html>
  )
}
