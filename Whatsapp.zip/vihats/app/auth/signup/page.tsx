'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { hashPin } from '@/lib/hash'
import { useAuthStore } from '@/lib/store'
import { requestNotificationPermission, initSW } from '@/lib/notifications'

const COLORS = ['#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFD93D','#C77DFF','#FF9F43','#00D2D3','#FF6B9D','#A8E6CF']

export default function SignupPage() {
  const router = useRouter()
  const setUser = useAuthStore(s => s.setUser)
  const [step, setStep] = useState<'info' | 'pin' | 'confirm'>('info')
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [color, setColor] = useState(COLORS[Math.floor(Math.random() * COLORS.length)])
  const [pin, setPin] = useState(['', '', '', ''])
  const [confirm, setConfirm] = useState(['', '', '', ''])
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const pinRefs = useRef<(HTMLInputElement | null)[]>([])
  const conRefs = useRef<(HTMLInputElement | null)[]>([])

  const checkInfo = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !username.trim()) return
    setLoading(true); setErr('')
    const clean = username.trim().toLowerCase().replace(/[^a-z0-9_.]/g, '')
    const { data } = await supabase.from('users').select('id').ilike('username', clean).maybeSingle()
    setLoading(false)
    if (data) { setErr('Username taken. Try another.'); return }
    setUsername(clean); setStep('pin')
    setTimeout(() => pinRefs.current[0]?.focus(), 80)
  }

  const onPin = (refs: React.MutableRefObject<(HTMLInputElement | null)[]>, arr: string[], set: (v: string[]) => void, i: number, val: string, done?: (v: string) => void) => {
    if (!/^\d*$/.test(val)) return
    const p = [...arr]; p[i] = val.slice(-1); set(p)
    if (val && i < 3) refs.current[i + 1]?.focus()
    if (p.every(d => d) && done) done(p.join(''))
  }

  const onKey = (refs: React.MutableRefObject<(HTMLInputElement | null)[]>, arr: string[], i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !arr[i] && i > 0) refs.current[i - 1]?.focus()
  }

  const pinDone = () => { setStep('confirm'); setTimeout(() => conRefs.current[0]?.focus(), 80) }

  const confirmDone = async (val: string) => {
    if (pin.join('') !== val) {
      setErr("PINs don't match."); setConfirm(['', '', '', ''])
      setTimeout(() => conRefs.current[0]?.focus(), 60); return
    }
    setLoading(true); setErr('')
    const pin_hash = await hashPin(pin.join(''))
    const { data, error } = await supabase.from('users').insert({
      username, display_name: name.trim(), avatar_color: color, pin_hash, is_og: false
    }).select().single()
    if (error || !data) { setLoading(false); setErr('Something went wrong.'); return }
    setUser(data); initSW(); await requestNotificationPermission()
    router.push('/chat')
  }

  const stepIdx = ['info', 'pin', 'confirm'].indexOf(step)

  return (
    <div className="h-screen flex items-center justify-center p-4 relative overflow-hidden" style={{ background: '#080b14' }}>
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center" style={{ transform: 'translateY(-60px)' }}>
        <div style={{ width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(0,229,255,0.045) 0%, transparent 70%)' }} />
      </div>

      <div className="w-full max-w-[360px] relative z-10 afu">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-[60px] h-[60px] rounded-[18px] mb-4"
            style={{ background: 'linear-gradient(145deg,#0a1e2c,#003d4d)', border: '1px solid rgba(0,229,255,0.18)' }}>
            <svg width="28" height="28" viewBox="0 0 40 40" fill="none">
              <path d="M20 3C10.61 3 3 10.61 3 20c0 3.12.83 6.04 2.27 8.57L3 37l8.74-2.22A16.9 16.9 0 0020 37c9.39 0 17-7.61 17-17S29.39 3 20 3z" fill="#00e5ff" />
            </svg>
          </div>
          <h1 className="font-display text-2xl font-bold" style={{ color: '#f0f6ff' }}>Create Account</h1>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.28)' }}>Join VI-hatsApp</p>
        </div>

        {/* Progress */}
        <div className="flex gap-1.5 mb-8">
          {[0, 1, 2].map(i => (
            <div key={i} className="h-1 rounded-full flex-1 transition-all duration-300"
              style={{ background: i <= stepIdx ? '#00e5ff' : 'rgba(255,255,255,0.08)' }} />
          ))}
        </div>

        {step === 'info' && (
          <form onSubmit={checkInfo} className="space-y-4">
            <div>
              <label className="block text-xs font-display font-semibold uppercase tracking-[.12em] mb-2" style={{ color: 'rgba(255,255,255,0.22)' }}>Display Name</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Ahmad Baig" autoFocus
                className="w-full rounded-2xl px-4 py-[15px] text-base outline-none transition-all placeholder:opacity-30"
                style={{ background: '#0e1520', border: '1.5px solid #1a2640', color: '#f0f6ff' }}
                onFocus={e => e.target.style.borderColor = '#00e5ff'}
                onBlur={e => e.target.style.borderColor = '#1a2640'} />
            </div>
            <div>
              <label className="block text-xs font-display font-semibold uppercase tracking-[.12em] mb-2" style={{ color: 'rgba(255,255,255,0.22)' }}>Username</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-base" style={{ color: 'rgba(255,255,255,0.2)' }}>@</span>
                <input value={username} onChange={e => { setUsername(e.target.value); setErr('') }} placeholder="ahmad_baig"
                  className="w-full rounded-2xl pl-8 pr-4 py-[15px] text-base outline-none transition-all placeholder:opacity-30"
                  style={{ background: '#0e1520', border: '1.5px solid #1a2640', color: '#f0f6ff' }}
                  onFocus={e => e.target.style.borderColor = '#00e5ff'}
                  onBlur={e => e.target.style.borderColor = '#1a2640'} />
              </div>
            </div>
            <div>
              <label className="block text-xs font-display font-semibold uppercase tracking-[.12em] mb-2.5" style={{ color: 'rgba(255,255,255,0.22)' }}>Pick a colour</label>
              <div className="flex gap-2 flex-wrap">
                {COLORS.map(c => (
                  <button key={c} type="button" onClick={() => setColor(c)}
                    className="w-8 h-8 rounded-xl transition-all"
                    style={{ background: c, outline: color === c ? `3px solid white` : 'none', outlineOffset: '2px', transform: color === c ? 'scale(1.15)' : 'scale(1)' }} />
                ))}
              </div>
            </div>
            {err && <p className="text-red-400 text-sm">{err}</p>}
            <button type="submit" disabled={!name.trim() || !username.trim() || loading}
              className="w-full py-[15px] rounded-2xl font-display font-bold text-base transition-all disabled:opacity-40 flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg,#00e5ff,#00b8cc)', color: '#080b14', boxShadow: '0 4px 24px rgba(0,229,255,0.25)' }}>
              {loading ? <span className="w-5 h-5 rounded-full border-2 border-[#080b14]/40 border-t-[#080b14] spin inline-block" /> : 'Continue →'}
            </button>
            <p className="text-center text-sm" style={{ color: 'rgba(255,255,255,0.25)' }}>
              Already have an account?{' '}
              <Link href="/" className="underline underline-offset-2" style={{ color: '#00e5ff' }}>Log in</Link>
            </p>
          </form>
        )}

        {(step === 'pin' || step === 'confirm') && (
          <div>
            <button onClick={() => step === 'pin' ? setStep('info') : setStep('pin')}
              className="flex items-center gap-1.5 text-sm mb-8 transition-opacity hover:opacity-60"
              style={{ color: 'rgba(255,255,255,0.35)' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 18l-6-6 6-6" /></svg>
              Back
            </button>
            <div className="text-center mb-8">
              <div className="av w-[64px] h-[64px] rounded-[18px] text-2xl mx-auto mb-3"
                style={{ background: color + '20', color, border: `2px solid ${color}35` }}>
                {name[0]?.toUpperCase()}
              </div>
              <p className="font-semibold" style={{ color: '#f0f6ff' }}>{name}</p>
              <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.28)' }}>
                {step === 'pin' ? 'Set a 4-digit PIN' : 'Confirm your PIN'}
              </p>
            </div>
            <div className="flex justify-center gap-3 mb-4">
              {(step === 'pin' ? pin : confirm).map((d, i) => (
                <input key={i}
                  ref={el => { (step === 'pin' ? pinRefs : conRefs).current[i] = el }}
                  type="password" inputMode="numeric" maxLength={1} value={d}
                  onChange={e => step === 'pin'
                    ? onPin(pinRefs, pin, setPin, i, e.target.value, pinDone)
                    : onPin(conRefs, confirm, setConfirm, i, e.target.value, confirmDone)}
                  onKeyDown={e => step === 'pin'
                    ? onKey(pinRefs, pin, i, e)
                    : onKey(conRefs, confirm, i, e)}
                  className="pin-box" disabled={loading} />
              ))}
            </div>
            {err && <p className="text-center text-red-400 text-sm mt-2 afi">{err}</p>}
            {step === 'pin' && <p className="text-center text-xs mt-3" style={{ color: 'rgba(255,255,255,0.2)' }}>You'll need this to log in</p>}
            {loading && (
              <div className="flex justify-center gap-2 mt-5">
                {[0, 1, 2].map(i => <div key={i} className="w-2 h-2 rounded-full" style={{ background: '#00e5ff', animation: `tdot 1.3s ease-in-out ${i * .18}s infinite` }} />)}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
