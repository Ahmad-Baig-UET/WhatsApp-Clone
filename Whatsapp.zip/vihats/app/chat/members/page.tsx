'use client'
import { useAuthStore } from '@/lib/store'

export default function MembersPage() {
  const user = useAuthStore(s => s.user)
  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="text-center max-w-sm animate-fade-up">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6"
          style={{ background: 'linear-gradient(135deg, #0d1f2d, #003d4d)', border: '1px solid rgba(0,229,255,0.2)', boxShadow: '0 0 30px rgba(0,229,255,0.1)' }}>
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none"><path d="M20 4C11.16 4 4 11.16 4 20c0 2.93.78 5.66 2.13 8.04L4 36l8.44-2.09A15.9 15.9 0 0020 36c8.84 0 16-7.16 16-16S28.84 4 20 4z" fill="#00e5ff"/></svg>
        </div>
        <h1 className="font-display text-2xl font-bold text-white mb-2">Welcome, {user?.display_name}! 👋</h1>
        <p className="text-slate-muted mb-6 leading-relaxed">
          Pick someone from the sidebar to start a private conversation.
          <br/><br/>
          The group chat is exclusive to the original VI-hatsApp crew.
        </p>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm"
          style={{ background: 'rgba(0,229,255,0.08)', border: '1px solid rgba(0,229,255,0.2)', color: '#00e5ff' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
          Tap any name in the sidebar to DM them
        </div>
      </div>
    </div>
  )
}
