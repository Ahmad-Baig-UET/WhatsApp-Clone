'use client'
import { useEffect, useState, useCallback, useRef } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/lib/store'
import type { User, DMChat } from '@/lib/supabase'

export default function ChatLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const user = useAuthStore(s => s.user)
  const logout = useAuthStore(s => s.logout)
  const [users, setUsers] = useState<User[]>([])
  const [dms, setDms] = useState<DMChat[]>([])
  const [search, setSearch] = useState('')
  const [mob, setMob] = useState(false)
  const subRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  useEffect(() => { if (!user) router.replace('/') }, [user, router])

  const load = useCallback(async () => {
    if (!user) return
    // All users except self
    const { data: allUsers } = await supabase
      .from('users').select('id,username,display_name,avatar_color,is_og')
      .neq('id', user.id).order('display_name')

    // DM chats
    const { data: dmData } = await supabase.from('dm_chats').select('*')
      .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)

    if (!allUsers) return
    setUsers(allUsers as User[])

    if (!dmData?.length) { setDms([]); return }

    // Last message per DM — one query
    const ids = dmData.map((d: { id: string }) => d.id)
    const { data: msgs } = await supabase.from('messages')
      .select('id,chat_id,content,image_url,user_id,created_at')
      .in('chat_id', ids).order('created_at', { ascending: false })

    // Unread — message ids already read by me
    const { data: read } = await supabase.from('read_receipts')
      .select('message_id').eq('user_id', user.id)
    const readSet = new Set((read || []).map((r: { message_id: string }) => r.message_id))

    const enriched: DMChat[] = dmData.map((dm: DMChat) => {
      const otherId = dm.user_a === user.id ? dm.user_b : dm.user_a
      const otherUser = allUsers.find((u: User) => u.id === otherId) as User | undefined
      const dmMsgs = (msgs || []).filter((m: { chat_id: string }) => m.chat_id === dm.id)
      const lastMessage = dmMsgs[0] as DMChat['lastMessage']
      const unread = dmMsgs.filter((m: { user_id: string; id: string }) =>
        m.user_id !== user.id && !readSet.has(m.id)
      ).length
      return { ...dm, otherUser, lastMessage, unread }
    })

    // Sort: most recent first
    enriched.sort((a, b) => {
      const ta = a.lastMessage?.created_at || a.created_at
      const tb = b.lastMessage?.created_at || b.created_at
      return new Date(tb).getTime() - new Date(ta).getTime()
    })
    setDms(enriched)
  }, [user])

  useEffect(() => { load() }, [load])

  // Realtime sidebar refresh
  useEffect(() => {
    if (!user) return
    const ch = supabase.channel('sidebar-live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'dm_chats' }, load)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, load)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'read_receipts' }, load)
      .subscribe()
    subRef.current = ch
    return () => { supabase.removeChannel(ch) }
  }, [user, load])

  const startDM = async (otherId: string) => {
    if (!user) return
    const { data: ex } = await supabase.from('dm_chats').select('id')
      .or(`and(user_a.eq.${user.id},user_b.eq.${otherId}),and(user_a.eq.${otherId},user_b.eq.${user.id})`)
      .maybeSingle()
    if (ex) { router.push(`/chat/dm/${ex.id}`); setMob(false); return }
    const { data: nd } = await supabase.from('dm_chats')
      .insert({ user_a: user.id, user_b: otherId }).select().single()
    if (nd) { router.push(`/chat/dm/${nd.id}`); setMob(false); load() }
  }

  if (!user) return null

  const filtered = search.trim()
    ? users.filter(u => u.display_name.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase()))
    : users

  const SB = () => (
    <div className="flex flex-col h-full" style={{ background: '#090d18' }}>
      {/* Top bar */}
      <div className="px-3 pt-4 pb-3 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <div className="flex items-center gap-2.5 mb-3">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center"
              style={{ background: 'linear-gradient(145deg,#0a1e2c,#003d4d)', border: '1px solid rgba(0,229,255,0.2)' }}>
              <svg width="13" height="13" viewBox="0 0 40 40" fill="none"><path d="M20 3C10.61 3 3 10.61 3 20c0 3.12.83 6.04 2.27 8.57L3 37l8.74-2.22A16.9 16.9 0 0020 37c9.39 0 17-7.61 17-17S29.39 3 20 3z" fill="#00e5ff" /></svg>
            </div>
            <span className="font-display font-bold text-base tracking-tight" style={{ color: '#f0f6ff' }}>VI-hatsApp</span>
          </div>
          <button onClick={() => { logout(); router.replace('/') }}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:opacity-70"
            style={{ background: 'rgba(239,68,68,0.1)', color: 'rgba(239,68,68,0.7)' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" /></svg>
          </button>
        </div>
        {/* Self */}
        <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
          <div className="av w-8 h-8 rounded-lg text-sm flex-shrink-0"
            style={{ background: user.avatar_color + '22', color: user.avatar_color }}>
            {user.display_name[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="font-semibold text-sm leading-none truncate" style={{ color: '#f0f6ff' }}>{user.display_name}</p>
              {user.is_og && <span className="og">OG</span>}
            </div>
            <p className="text-xs mt-0.5 truncate" style={{ color: 'rgba(255,255,255,0.25)' }}>@{user.username}</p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="px-3 py-2.5 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2.5"><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" /></svg>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search people..."
            className="w-full rounded-xl pl-9 pr-4 py-2.5 text-sm outline-none placeholder:opacity-100"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)', color: '#f0f6ff', caretColor: '#00e5ff' }}
            onFocus={e => e.target.style.borderColor = 'rgba(0,229,255,0.3)'}
            onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.06)'} />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-px">
        {/* Group */}
        {user.is_og && !search && (
          <>
            <p className="px-3 py-1.5 text-[10px] font-display font-semibold uppercase tracking-[.12em]" style={{ color: 'rgba(255,255,255,0.18)' }}>Group</p>
            <Link href="/chat" onClick={() => setMob(false)}
              className={`nav-item flex items-center gap-3 px-3 py-2.5 w-full ${pathname === '/chat' ? 'active' : ''}`}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'linear-gradient(145deg,#003544,#004a5e)', border: '1px solid rgba(0,229,255,0.22)' }}>
                <svg width="15" height="15" viewBox="0 0 40 40" fill="none"><path d="M20 3C10.61 3 3 10.61 3 20c0 3.12.83 6.04 2.27 8.57L3 37l8.74-2.22A16.9 16.9 0 0020 37c9.39 0 17-7.61 17-17S29.39 3 20 3z" fill="#00e5ff" /></svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate" style={{ color: '#f0f6ff' }}>VI-hatsApp Group</p>
                <p className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.25)' }}>OGs only 🔒</p>
              </div>
            </Link>
          </>
        )}

        {/* DMs */}
        {dms.length > 0 && !search && (
          <>
            <p className="px-3 pt-2 pb-1.5 text-[10px] font-display font-semibold uppercase tracking-[.12em]" style={{ color: 'rgba(255,255,255,0.18)' }}>Messages</p>
            {dms.map(dm => {
              const preview = dm.lastMessage?.content || (dm.lastMessage?.image_url ? '🖼️ Image' : 'Say hi!')
              return (
                <Link key={dm.id} href={`/chat/dm/${dm.id}`} onClick={() => setMob(false)}
                  className={`nav-item flex items-center gap-3 px-3 py-2.5 w-full ${pathname === `/chat/dm/${dm.id}` ? 'active' : ''}`}>
                  <div className="av w-9 h-9 rounded-xl text-sm flex-shrink-0"
                    style={{ background: (dm.otherUser?.avatar_color || '#888') + '22', color: dm.otherUser?.avatar_color || '#888' }}>
                    {(dm.otherUser?.display_name || '?')[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <p className="font-semibold text-sm truncate" style={{ color: '#f0f6ff' }}>{dm.otherUser?.display_name}</p>
                      {(dm.unread || 0) > 0 && (
                        <span className="flex-shrink-0 w-5 h-5 rounded-full text-[10px] font-bold font-display flex items-center justify-center"
                          style={{ background: '#00e5ff', color: '#080b14' }}>{dm.unread}</span>
                      )}
                    </div>
                    <p className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.25)' }}>{preview}</p>
                  </div>
                </Link>
              )
            })}
          </>
        )}

        {/* People */}
        {filtered.length > 0 && (
          <>
            <p className="px-3 pt-2 pb-1.5 text-[10px] font-display font-semibold uppercase tracking-[.12em]" style={{ color: 'rgba(255,255,255,0.18)' }}>People</p>
            {filtered.map(u => (
              <button key={u.id} onClick={() => startDM(u.id)}
                className="nav-item flex items-center gap-3 px-3 py-2.5 w-full text-left">
                <div className="av w-9 h-9 rounded-xl text-sm flex-shrink-0"
                  style={{ background: u.avatar_color + '22', color: u.avatar_color }}>
                  {u.display_name[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="font-semibold text-sm truncate" style={{ color: '#f0f6ff' }}>{u.display_name}</p>
                    {u.is_og && <span className="og">OG</span>}
                  </div>
                  <p className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.25)' }}>@{u.username}</p>
                </div>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" /></svg>
              </button>
            ))}
          </>
        )}
      </div>
    </div>
  )

  return (
    <div className="flex overflow-hidden" style={{ height: '100dvh', background: '#080b14' }}>
      {/* Desktop sidebar */}
      <aside className="hidden md:block w-[268px] flex-shrink-0" style={{ borderRight: '1px solid rgba(255,255,255,0.05)' }}>
        <SB />
      </aside>

      {/* Mobile overlay */}
      {mob && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="w-[268px] flex-shrink-0 asl" style={{ borderRight: '1px solid rgba(255,255,255,0.05)' }}><SB /></div>
          <div className="flex-1 bg-black/60 backdrop-blur-sm" onClick={() => setMob(false)} />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile topbar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 flex-shrink-0" style={{ background: '#090d18', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
          <button onClick={() => setMob(true)} style={{ color: 'rgba(255,255,255,0.4)' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" /></svg>
          </button>
          <span className="font-display font-bold" style={{ color: '#f0f6ff' }}>VI-hatsApp</span>
        </div>
        {children}
      </div>
    </div>
  )
}
