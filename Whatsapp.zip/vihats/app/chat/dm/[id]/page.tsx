'use client'
import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/lib/store'
import ChatWindow from '@/components/ChatWindow'
import type { User } from '@/lib/supabase'

export default function DMPage() {
  const { id } = useParams<{ id: string }>()
  const user = useAuthStore(s => s.user)
  const [other, setOther] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user || !id) return
    setOther(null); setLoading(true)
    supabase.from('dm_chats').select('*').eq('id', id).single().then(({ data: dm }) => {
      if (!dm) { setLoading(false); return }
      const otherId = dm.user_a === user.id ? dm.user_b : dm.user_a
      supabase.from('users').select('*').eq('id', otherId).single().then(({ data: u }) => {
        setOther(u as User)
        setLoading(false)
      })
    })
  }, [id, user])

  if (loading) return (
    <div className="flex-1 flex items-center justify-center">
      <div className="w-6 h-6 rounded-full border-2 border-t-transparent spin" style={{ borderColor: 'rgba(0,229,255,0.3)', borderTopColor: 'transparent' }} />
    </div>
  )

  if (!other) return (
    <div className="flex-1 flex items-center justify-center">
      <p style={{ color: 'rgba(255,255,255,0.3)' }}>Chat not found.</p>
    </div>
  )

  // key={id} forces full ChatWindow remount when switching chats — fixes stale state
  return <ChatWindow key={id} chatId={id} title={other.display_name} subtitle={`@${other.username}`} avatarColor={other.avatar_color} />
}
