'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuthStore } from '@/lib/store'
import ChatWindow from '@/components/ChatWindow'

export default function GroupPage() {
  const user = useAuthStore(s => s.user)
  const router = useRouter()
  useEffect(() => { if (user && !user.is_og) router.replace('/chat/members') }, [user, router])
  if (!user) return null
  if (!user.is_og) return (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="text-center">
        <div className="text-5xl mb-4">🔒</div>
        <h2 className="font-display text-xl font-bold mb-2" style={{ color: '#f0f6ff' }}>OGs Only</h2>
        <p style={{ color: 'rgba(255,255,255,0.3)' }}>This group is for the original 6 members.</p>
      </div>
    </div>
  )
  return <ChatWindow chatId="group" title="VI-hatsApp Group" subtitle="The OG crew 🔒" isGroup />
}
