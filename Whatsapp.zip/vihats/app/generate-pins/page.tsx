'use client'
import { useState } from 'react'
import { hashPin } from '@/lib/hash'

export default function GeneratePins() {
  const [pin, setPin] = useState('')
  const [hash, setHash] = useState('')
  const generate = async () => { if (pin.length === 4) setHash(await hashPin(pin)) }
  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center p-8">
      <div className="max-w-md w-full bg-ink-900 border border-slate-border rounded-2xl p-8">
        <h1 className="font-display text-xl text-cyan mb-2">PIN Hash Generator</h1>
        <p className="text-slate-muted text-sm mb-6">⚠️ Delete this page before going live!</p>
        <input type="text" inputMode="numeric" maxLength={4} value={pin}
          onChange={e => setPin(e.target.value.replace(/\D/g,''))} placeholder="4-digit PIN"
          className="w-full bg-ink-800 border border-slate-border rounded-xl px-4 py-3 text-white font-display text-lg text-center outline-none focus:border-cyan mb-4"/>
        <button onClick={generate} disabled={pin.length !== 4}
          className="w-full py-3 rounded-xl font-semibold text-ink-950 disabled:opacity-40"
          style={{ background: 'linear-gradient(135deg, #00e5ff, #00b8cc)' }}>Generate Hash</button>
        {hash && (
          <div className="mt-6">
            <p className="text-slate-muted text-xs mb-2">Hash for PIN <span className="text-cyan font-bold">{pin}</span>:</p>
            <code className="block text-xs text-white bg-ink-950 border border-slate-border rounded-xl p-3 break-all cursor-pointer hover:border-cyan transition-colors"
              onClick={() => navigator.clipboard.writeText(hash)} title="Click to copy">{hash}</code>
            <p className="text-slate-muted text-xs mt-2 text-center">Click to copy</p>
          </div>
        )}
      </div>
    </div>
  )
}
